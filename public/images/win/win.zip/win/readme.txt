﻿如果你可以看到本文件，请务必看下面的说明：



1、如果还是连接失败，请卸载360、电脑管家后重启电脑



2、请卸载其他同类的VPN代理软件，或者联系网站的客服



3、如果提示运行错误或者 .NET版本问题 ，请先下载安装



https://download.microsoft.com/download/6/4/c/64c45308-d7e1-43b7-9b12-8de90cd8d1b6/ndp481-x86-x64-allos-chs.exe